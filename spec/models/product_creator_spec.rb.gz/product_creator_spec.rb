# -*- coding: utf-8 -*-
require 'rails_helper'

RSpec.describe ProductCreator, type: :model do

  before do
      @product = Product.new(name: "Nutella", image: "http://static.openfoodfacts.org/images/products/000/980/089/5250/front_en.21.200.jpg", quantity: "750 g", brands: "Nutella,Ferrero", categories: "Petit-déjeuners,Produits à tartiner,Produits à tartiner sucrés,Pâtes à tartiner,Pâtes à tartiner au chocolat,Pâtes à tartiner aux noisettes,Pâtes à tartiner aux noisettes et au cacao", ingredients: "SUGAR, PALM OIL, _HAZELNUTS_, COCOA, SKIM MILK, REDUCED MINERALS WHEY (MILK), LECITHIN AS EMULSIFIER (SOY), VANILLIN: AN ARTIFICIAL FLAVOR", upc_code: "0009800895250")
  end

  subject { @product }
   
  it { should respond_to(:name) }
 
  let(:creator) { ProductCreator.new ActionController::Parameters.new() }
  #Rails.logger.info("TP creator #{:creator.inspect}")
  describe "#ok?" do
    subject { creator.ok? }
    #context "x" do
    #  it {should be_truthy}
    #end
    it "saves the product" do
      #expect { subject }.to change { creator.product.new_record? }
      Rails.logger.info("TP creator: #{creator.inspect}")

    end

  end

end
