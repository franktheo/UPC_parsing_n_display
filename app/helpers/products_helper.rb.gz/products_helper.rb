require 'json'
require 'open-uri'

module ProductsHelper

  def url_and_json_data_status(upc_code)

     url = File.join('http://world.openfoodfacts.org/api/v0/product',upc_code.concat(".json"))
     data = open(url).read rescue false

     Rails.logger.info("TP data: #{data.inspect}")
     
     obj = JSON.parse(data)
     if obj["status"] == 0
        return 0
        Rails.logger.info("TP product not found")
     end
     return 1

  end

  def upc_parse upc_code

     url = 'http://world.openfoodfacts.org/api/v0/product/0020662000200.json'
     data = open(url).read
     obj = JSON.parse(data)
     product = obj['product']

     product_name = product['product_name']

     image_small_url = product['image_small_url']

     quantity = product['quantity']

     brands = product['brands']
     logger.info("TP brands: #{brands}")

     categories = product['categories']

     ingredients_text = product['ingredients_text']
     
  end

end
